//-----------------------------------------------:
// File     : LAB_0704.c
// Purpose  : CCP1 (PWM Mode)
// Author   : Prajin Palangsantikul
// Compiler : MPLAB C18 Compiler
// Target   : PIC18Fxxxx
//-----------------------------------------------:
#include <p18cxxx.h>  // Device config form Project
#include <delays.h>   // PIC18 cycle-count delay routines
#include <timers.h>   // Tiemrs Function
#include <pwm.h>      // Pulse-Width Modulation Functions

//-----------------------------------------------:Configuration Bits
// HS Oscillator Selection, Watchdog Timer OFF
#pragma config OSC = HS,  WDT = OFF
// Low Voltage Programming : Disabled
#pragma config LVP = OFF

//-----------------------------------------------:delay for 1 ms
void delay_ms(unsigned int ms)
{ 
  for (;ms>0;ms--) 
  {
    Delay1KTCYx(5);  // Delay of 1 ms
  }
}

//-----------------------------------------------:Main
void main (void)
{
  unsigned int dutycycle;
  
  PORTA = 0;  // Clear PORTA register 
  LATA = 0;   // Clear LATA register
  PORTC = 0;  // Clear PORTC register 
  LATC = 0;   // Clear LATc register

  TRISAbits.TRISA0 = 0;   // Set RA0 output
  TRISCbits.TRISC2 = 0;   // Set RC2/CCP1 Output
  
  // Timer2 Configure
  OpenTimer2(TIMER_INT_OFF & // Disable Timer2 Interrupts
             T2_PS_1_1);     // Prescaler 1:1
             
  // CCP1 Configure
  OpenPWM1(63);             // PWM frequency 
  SetDCPWM1(5);             // Set Duty cycle
    
  while (1)
  {
    LATAbits.LATA0 = 1;   // High RA0
    delay_ms(100);        // Delay 0.1s
    LATAbits.LATA0 = 0;   // Low RA0
    delay_ms(100);        // Delay 0.1s
    dutycycle += 5;       // Up +5
    if (dutycycle>255)    // 8Bit Resolutions
      dutycycle = 5;
    SetDCPWM1(dutycycle); // change duty cycle
  }
}
