//-----------------------------------------------:
// Workfile    : LIB_LCD.c
// Purpose     : LCD Library
// Author      : Prajin Palangsantikul
// Company     : appsofttech co.,ltd.
// Compiler    : MPLAB C18
// Target      : PIC18
// Ref         : XLCD (MPLAB C18 Libraries..)
//-----------------------------------------------:

//-----------------------------------------------:LCD PIN
// RB0 -> LCD D4
// RB1 -> LCD D5
// RB2 -> LCD D6
// RB3 -> LCD D7
// RB4 -> LCD E 
// RB5 -> LCD RS
// RB6 -> LCD R/W

//-----------------------------------------------:
#include <xlcd.h>           // PIC18 XLCD peripheral routines.
#include <delays.h>         // PIC18 cycle-count delay routines.
#include <stdlib.h>

//-----------------------------------------------:Delay for 18 cycles
void DelayFor18TCY(void)
{ 
  Nop(); Nop(); Nop(); Nop(); 
  Nop(); Nop(); Nop(); Nop(); 
  Nop(); Nop(); Nop(); Nop(); 
  Nop(); Nop(); Nop(); Nop();
  Nop(); Nop();
}

//-----------------------------------------------:Delay for 5 ms
void DelayXLCD(void)     
{ 
  Delay1KTCYx(25);  // Delay of 5 ms
                    // Cycles = (TimeDelay * Fosc) / 4
                    // Cycles = (5ms * 20MHz) / 4
                    // Cycles = 25,000
}

//-----------------------------------------------:Delay for 15 ms
void DelayPORXLCD(void)  
{ 
  Delay1KTCYx(75);  // Delay of 15 ms
                    // Cycles = (TimeDelay * Fosc) / 4
                    // Cycles = (15ms * 20MHz) / 4
                    // Cycles = 75,000
}

//-----------------------------------------------:Wait .. LCD
void WaitLCD(void)
{
  while(BusyXLCD());      // Wait while LCD is busy
  DelayXLCD();     
}

//-----------------------------------------------:LCD gotoxy
// x:1->16, y:1->4
static void LCD_gotoxy(char x, char y)
{
  char address;
  while ( BusyXLCD() );
  DelayXLCD();
  switch(y) {
     case 1 : address=0x80;break;
     case 2 : address=0xc0;break;
     //case 3 : address=0x94;break;
     //case 4 : address=0xd4;break;
     case 3 : address=0x90;break;
     case 4 : address=0xd0;break;
   }
   address+=x-1;
   WriteCmdXLCD(address);
}

//-----------------------------------------------:
void putrsXLCD(const rom char *buffer)
{
  DelayXLCD();
  while(*buffer)                  // Write data to LCD up to null
  {
    while(BusyXLCD());      // Wait while LCD is busy
    Nop(); Nop();           // Prajin....
    WriteDataXLCD(*buffer); // Write character to LCD
    buffer++;               // Increment buffer
  }
  return;
}

//-----------------------------------------------:
void putsXLCD(char *buffer)
{
  DelayXLCD();
  while(*buffer)                  // Write data to LCD up to null
  {
    while(BusyXLCD());      // Wait while LCD is busy
    Nop(); Nop();           // Prajin....
    WriteDataXLCD(*buffer); // Write character to LCD
    buffer++;               // Increment buffer
  }      
  return;
}

