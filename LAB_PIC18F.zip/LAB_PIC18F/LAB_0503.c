//-----------------------------------------------:
// File     : LAB_0503.c
// Purpose  : External Interrupt (INT0/RB0, INT1/RB1)
// Author   : Prajin Palangsantikul
// Compiler : MPLAB C18 Compiler
// Target   : PIC18Fxxxx
//-----------------------------------------------:
#include <p18cxxx.h>  // Device config form Project
#include <delays.h>   // PIC18 cycle-count delay routines.
#include <portb.h>    // I/O Port Functions.

//-----------------------------------------------:Configuration Bits
// HS Oscillator Selection, Watchdog Timer OFF
#pragma config OSC = HS,  WDT = OFF
// Low Voltage Programming : Disabled
#pragma config LVP = OFF

//-----------------------------------------------:Prototype
void InterruptHandlerHigh (void);
void InterruptHandlerLow (void);
void delay_ms(unsigned int ms);

//-----------------------------------------------:Interrupt vector
// High priority interrupt vector
#pragma code InterruptVectorHigh = 0x08
void InterruptVectorHigh (void)
{
  _asm
    goto InterruptHandlerHigh //jump to interrupt routine
  _endasm
}
// Low priority interrupt vector
#pragma code InterruptVectorLow = 0x18
void InterruptVectorLow (void)
{
  _asm
    goto InterruptHandlerLow //jump to interrupt routine
  _endasm
}

// return to the default code section
#pragma code

//-----------------------------------------------:Interrupt routine
// High priority interrupt routine
#pragma interrupt InterruptHandlerHigh
void InterruptHandlerHigh (void)
{
  if (INTCONbits.INT0IF)    // Check for INT0 Interrupt
  {    
    INTCONbits.INT0IF = 0;  // Clear interrupt flag
    LATAbits.LATA2 = 1;     // RA2 High
    delay_ms(500);          
    LATAbits.LATA2 = 0;     // RA2 Low
  }
}
// Low priority interrupt routine
#pragma interrupt InterruptHandlerLow
void InterruptHandlerLow (void)
{
  if (INTCON3bits.INT1IF)    // Check for INT1 Interrupt
  {    
    INTCON3bits.INT1IF = 0; // Clear interrupt flag
    LATAbits.LATA3 = 1;     // High RA3
    delay_ms(500);          
    LATAbits.LATA3 = 0;     // Low RA3
  }
}

//-----------------------------------------------:delay for 1 ms
void delay_ms(unsigned int ms)
{ 
  for (;ms>0;ms--) 
  {
    Delay1KTCYx(5);  // Delay of 1 ms
  }
}

//-----------------------------------------------:Main
void main (void)
{
  PORTA = 0;  // Clear PORTA register 
  LATA = 0;   // Clear LATA register
  PORTB = 0;  // Clear PORTB register 
  LATB = 0;   // Clear LATB register 
  
  TRISAbits.TRISA0 = 0;   // Set RA0/1/2/3 output
  TRISAbits.TRISA1 = 0; 
  TRISAbits.TRISA2 = 0; 
  TRISAbits.TRISA3 = 0; 

  ADCON1 = 0x0F;        // Configure A/D for digital inputs

  // INT0 Configure 
  OpenRB0INT( PORTB_CHANGE_INT_ON &   // Enables Interrupt
              FALLING_EDGE_INT &      // Interrupt on falling edge
              PORTB_PULLUPS_OFF);     // Disable Pullups port

  // INT1 Configure 
  OpenRB1INT( PORTB_CHANGE_INT_ON &   // Enables Interrupt
              FALLING_EDGE_INT &      // Interrupt on falling edge
              PORTB_PULLUPS_OFF);     // Disable Pullups port

  INTCON3bits.INT1IP = 0; // Set low Priority Interrupt
  RCONbits.IPEN = 1;      // Enable priority levels on interrupts
  INTCONbits.PEIE = 1;    // Enable Peripheral Interrupt
  INTCONbits.GIE = 1;     // Enable global interrupts

  while (1)
  {             
    LATAbits.LATA0 = 1;   // RA0 High
    LATAbits.LATA1 = 0;   // RA1 Low
    delay_ms(500);        // Delay 0.5s
    LATAbits.LATA0 = 0;   // RA0 Low
    LATAbits.LATA1 = 1;   // RA1 High
    delay_ms(500);        // Delay 0.5s
  }
}
