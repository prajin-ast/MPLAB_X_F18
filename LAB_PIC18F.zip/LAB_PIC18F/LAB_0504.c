//-----------------------------------------------:
// File     : LAB_0504.c
// Purpose  : PORTB Interrupt-on-Change
// Author   : Prajin Palangsantikul
// Compiler : MPLAB C18 Compiler
// Target   : PIC18Fxxxx
//-----------------------------------------------:
#include <p18cxxx.h>  // Device config form Project
#include <delays.h>   // PIC18 cycle-count delay routines.
#include <portb.h>    // I/O Port Functions.

//-----------------------------------------------:Configuration Bits
// HS Oscillator Selection, Watchdog Timer OFF
#pragma config OSC = HS,  WDT = OFF
// Low Voltage Programming : Disabled
#pragma config LVP = OFF

//-----------------------------------------------:Prototype
void InterruptHandlerHigh (void);
void delay_ms(unsigned int ms);

//-----------------------------------------------:Interrupt vector
// High priority interrupt vector
#pragma code InterruptVectorHigh = 0x08
void InterruptVectorHigh (void)
{
  _asm
    goto InterruptHandlerHigh //jump to interrupt routine
  _endasm
}

// return to the default code section
#pragma code

//-----------------------------------------------:Interrupt routine
// High priority interrupt routine
#pragma interrupt InterruptHandlerHigh
void InterruptHandlerHigh (void)
{
  if (INTCONbits.RBIF)    // Check for RB Interrupt 
  {
    if (PORTBbits.RB4 == 0) // RB4 Interrupt
    {
      LATAbits.LATA0 = 1;
      delay_ms(100);          
      LATAbits.LATA0 = 0;
    } else 
    if (PORTBbits.RB5 == 0) // RB5 Interrupt
    {
      LATAbits.LATA1 = 1;
      delay_ms(100);          
      LATAbits.LATA1 = 0;
    } else 
    if (PORTBbits.RB6 == 0) // RB6 Interrupt
    {
      LATAbits.LATA2 = 1;
      delay_ms(100);          
      LATAbits.LATA2 = 0;
    } else 
    if (PORTBbits.RB7 == 0) // RB7 Interrupt
    {
      LATAbits.LATA3 = 1;
      delay_ms(100);          
      LATAbits.LATA3 = 0;
    }
    LATBbits.LATB2 = 1;   // RB4-RB7 Interrupt
    delay_ms(100);          
    LATBbits.LATB2 = 0;

    INTCONbits.RBIF = 0;  // Clear interrupt flag
  }
}
 
//-----------------------------------------------:delay for 1 ms
void delay_ms(unsigned int ms)
{ 
  for (;ms>0;ms--) 
  {
    Delay1KTCYx(5);  // Delay of 1 ms
  }
}

//-----------------------------------------------:Main
void main (void)
{  
  PORTA = 0;  // Clear PORTA register 
  LATA = 0;   // Clear LATA register
  PORTB = 0;  // Clear PORTB register 
  LATB = 0;   // Clear LATB register 
    
  TRISA = 0;              // Set PORTA output
  TRISBbits.TRISB0 = 0;   // Set RB0/1/2 output
  TRISBbits.TRISB1 = 0;
  TRISBbits.TRISB2 = 0;

  ADCON1 = 0x0F;          // Configure A/D for digital inputs
 
  // PORTB Interrupt-on-Change
  OpenPORTB( PORTB_CHANGE_INT_ON &  // Enables Interrupt
             PORTB_PULLUPS_ON );    // Enables Pullups port  
  
  INTCONbits.RBIF = 0;    // Clear interrupt flag
  INTCONbits.GIE = 1;     // Enable global interrupts
 
  while (1)
  {             
    LATBbits.LATB0 = 1;   // RB0 High
    LATBbits.LATB1 = 0;   // RB1 Low
    delay_ms(250);        // Delay 0.25s
    LATBbits.LATB0 = 0;   // RB0 Low
    LATBbits.LATB1 = 1;   // RB1 High
    delay_ms(250);        // Delay 0.25s
  }
}
