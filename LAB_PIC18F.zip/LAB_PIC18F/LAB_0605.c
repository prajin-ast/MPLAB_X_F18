//-----------------------------------------------:
// File     : LAB_0605.c
// Purpose  : TIMER2 (Timer mode)
// Author   : Prajin Palangsantikul
// Compiler : MPLAB C18 Compiler
// Target   : PIC18Fxxxx
//-----------------------------------------------:
#include <p18cxxx.h>  // Device config form Project
#include <delays.h>   // PIC18 cycle-count delay routines.
#include <timers.h>    // Timer Functions

//-----------------------------------------------:Configuration Bits
// HS Oscillator Selection, Watchdog Timer OFF
#pragma config OSC = HS,  WDT = OFF
// Low Voltage Programming : Disabled
#pragma config LVP = OFF

unsigned int count = 0;

//-----------------------------------------------:Prototype
void InterruptHandlerHigh (void);
void delay_ms(unsigned int ms);

//-----------------------------------------------:Interrupt vector
// High priority interrupt vector
#pragma code InterruptVectorHigh = 0x08
void InterruptVectorHigh (void)
{
  _asm
    goto InterruptHandlerHigh //jump to interrupt routine
  _endasm
}

// return to the default code section
#pragma code

//-----------------------------------------------:Interrupt routine
// High priority interrupt routine
#pragma interrupt InterruptHandlerHigh
void InterruptHandlerHigh (void)
{
  if (PIR1bits.TMR2IF)  // Check TMR2 interrupt flag 
  {
    if (count++ >= 1221)  
    {
      LATAbits.LATA0 = 1;   // RA0 High
      LATAbits.LATA1 = 1;   // RA1 High
      delay_ms(500);        // Delay 0.5s
      count = 0;            // Clear count
    }
    PIR1bits.TMR2IF = 0;  // Clear interrupt flag
  }
}

//-----------------------------------------------:delay for 1 ms
void delay_ms(unsigned int ms)
{ 
  for (;ms>0;ms--) 
  {
    Delay1KTCYx(5);  // Delay of 1 ms
  }
}

//-----------------------------------------------:Main
void main (void)
{
  PORTA = 0;  // Clear PORTA register 
  LATA = 0;   // Clear LATA register
    
  TRISAbits.TRISA0 = 0;   // Set RA0/1 output  
  TRISAbits.TRISA1 = 0;

  // Timer2 Configure
  OpenTimer2(TIMER_INT_ON &   // Interrupt enabled
             T2_PS_1_16 &     // 1:16 prescale
             T2_POST_1_1      // 1:1 postscale
             );
             
  INTCONbits.GIE = 1;     // Enable global interrupts
  INTCONbits.PEIE = 1;    // Enable peripheral Interrupt 
  WriteTimer2(0);         // Clear TMR2

  while (1)
  {             
    LATAbits.LATA0 = 1;   // RA0 High
    LATAbits.LATA1 = 0;   // RA1 Low
    delay_ms(100);        // Delay 0.1s
    LATAbits.LATA0 = 0;   // RA0 Low
    LATAbits.LATA1 = 1;   // RA1 High
    delay_ms(100);        // Delay 0.1s
  }
}
