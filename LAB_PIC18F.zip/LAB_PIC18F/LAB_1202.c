//-----------------------------------------------:
// File     : LAB_1202.c
// Purpose  : ADC
// Author   : Prajin Palangsantikul
// Compiler : MPLAB C18 Compiler
// Target   : PIC18Fxxxx
//-----------------------------------------------:
#include <p18cxxx.h>  // Device config form Project
#include <delays.h>   // PIC18 cycle-count delay routines
#include <usart.h>    // USART Functions
#include <stdlib.h>   // Use ultoa() Function
#include <adc.h>      // A/D Converter Functions

//-----------------------------------------------:Configuration Bits
// HS Oscillator Selection, Watchdog Timer OFF
#pragma config OSC = HS,  WDT = OFF
// Low Voltage Programming : Disabled
#pragma config LVP = OFF

//-----------------------------------------------:delay for 1 ms
void delay_ms(unsigned int ms)
{ 
  for (;ms>0;ms--) 
  {
    Delay1KTCYx(5);  // Delay of 1 ms
  }
}

//-----------------------------------------------:Read ADC
int read_adc(unsigned char ch)
{
  int result;
  
  if (ch == 0) SetChanADC(ADC_CH0); 
  if (ch == 1) SetChanADC(ADC_CH1); 
  
  Delay10TCYx(1);       // Delay for 10TCY
  ConvertADC();         // Start conversion
  while( BusyADC() );   // Wait for completion
  result = ReadADC();   // Read result  
  return (result);
}

//-----------------------------------------------:Main
void main (void)
{
  int value;
  char str[10];
  char stdout[30];
  float aFloat = 3.1415926535;
  
  // USART Configure
  OpenUSART(USART_TX_INT_OFF &  // Transmit interrupt OFF
            USART_RX_INT_OFF &  // Receive interrupt OFF
            USART_ASYNCH_MODE & // Asynchronous Mode
            USART_EIGHT_BIT &   // 8-bit transmit/receive
            USART_CONT_RX &     // Continuous reception
            USART_BRGH_HIGH,    // High baud rate
            129);               // 8N1 9600 baud
  
  // ADC Configure
  OpenADC(ADC_FOSC_16 &     // Fosc/16
          ADC_RIGHT_JUST &  // Result in Least Significant bits
          ADC_12_TAD,       // 12 Tad
          ADC_CH0 &         // Channel 0
          ADC_REF_VDD_VSS & // VREF+ = VDD & VREF- = VSS
          ADC_INT_OFF,      // Interrupts disabled
          ADC_2ANA);        // Analog:AN0-AN1
          
  while (1)
  {
    putrsUSART("\f10-BIT A/D Module");
    putrsUSART("\n\rADC[0]: ");
    value = read_adc(0);
    putsUSART(ultoa(value, str));
    
    putrsUSART("\n\rADC[1]: ");
    value = read_adc(1);
    putsUSART(ultoa(value, str));
    
    //fprintf(stdout, "%g", aFloat);
    //putsUSART(ultoa(aFloat, str));
    delay_ms(100);
  }
}
