/************************************************************************
*
* HLVD Power Down Save code example for PIC18F46J11 at 3.3V.
*
* This example demonstrates using an HLVD interrupt to quickly
* detect when power has been cut from the microcontroller.
*
* While powered, the firmware simply increments a counter 
* variable and displays the value on the serial port. When 
* power is cut, the firmware quickly saves data to 
* non-volatile FLASH memory during the short period of 
* time where capacitors are keeping the microcontroller 
* running.
*
* When power is restored, the firmware reads FLASH memory, 
* finds the most recently stored data and restores state.
* The counter then continues where it left off.
*
* This example is intended to operate at 8MHz, which is the
* maximum speed for this part to operate down to the minimum 
* Vdd specification. The minimum voltage for writing to FLASH
* is specified at 2.25V, but the write should still work if 
* enough capacitance is provided to keep Vddcore up for the 
* duration of the write.
*
* Config Bits Settings:	
*   Watch dog timer is disabled
*   Extended instruction mode is disabled
*   Oscillator is configured as 8MHz INTOSC
*   Fail safe monitor is enabled
*   Internal/External oscillator switch over is enabled	
*
*************************************************************************
* FileName:     main.c
* Dependencies: 
* Compiler:     MPLAB C18, v3.30 or higher
* Company:      Microchip Technology, Inc.
*
* Software License Agreement
*
* Copyright � 2009 Microchip Technology Inc. All rights reserved.
*
* Microchip licenses to you the right to use, modify, copy and distribute
* Software only when embedded on a Microchip microcontroller or digital
* signal controller, which is integrated into your product or third party
* product (pursuant to the sublicense terms in the accompanying license
* agreement).
*
* You should refer to the license agreement accompanying this Software for
* additional information regarding your rights and obligations.
*
* SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY
* KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY
* WARRANTY OF MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A
* PARTICULAR PURPOSE. IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE
* LIABLE OR OBLIGATED UNDER CONTRACT, NEGLIGENCE, STRICT LIABILITY,
* CONTRIBUTION, BREACH OF WARRANTY, OR OTHER LEGAL EQUITABLE THEORY ANY
* DIRECT OR INDIRECT DAMAGES OR EXPENSES INCLUDING BUT NOT LIMITED TO ANY
* INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR CONSEQUENTIAL DAMAGES, LOST
* PROFITS OR LOST DATA, COST OF PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY,
* SERVICES, OR ANY CLAIMS BY THIRD PARTIES (INCLUDING BUT NOT LIMITED TO
* ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*
* Author        Date        Comment
*************************************************************************
* E. Schlunder  2009/09/15  First release.
************************************************************************/

// BAUDRG is calculated as  = Fosc / (4 * Desired Baudrate) - 1
// So, 4MHz / (4 * 19200) - 1 = 52 (approx.)
// 32MHz / (4 * 115200) - 1 = 69
//#define BAUDRG 52                 // 19.2Kbps from 4MHz INTOSC
//#define BAUDRG 103                // 115.2Kbps from 48MHz
//#define BAUDRG 86                 // 115.2Kbps from 40MHz
//#define BAUDRG 68                 // 115.2Kbps from 32MHz
//#define BAUDRG 21                 // 115.2Kbps from 10MHz
#define BAUDRG 34                 // 57.6Kbps from 8MHz

#include <p18cxxx.h>
#include <stdio.h>
#include <usart.h>
#include <flash.h>

void wait(void);
void high_isr(void);
void WaitForStableVdd(void);
void WriteFlash(unsigned long startaddr, unsigned int data);
void RestoreSavedData(void);
void RecycleFlash(void);

#define FLASH_STORAGE_START 0xF000
#define FLASH_STORAGE_END   0xF400

#pragma udata access FastAccessRAM
volatile unsigned int counter = 0;
volatile near unsigned int flashAddress;

#pragma code AppHighIntVector = 0x0008  // hardware high priority interrupt vector address
void AppHighIntVector(void)
{
    _asm GOTO high_isr _endasm          // branch to the high_isr() function to handle priority interrupts.
}

#pragma code                            // return to the default code section
#pragma interrupt high_isr
 /*********************************************************************
 Function:        	void high_isr(void)
 PreCondition:    	FLASH memory space must be available, pointed to
                    by the flashAddress global variable.
 Input:           	None
 Output:          	None
 Side Effects:    	flashAddress is incremented by 2.
 Overview:        	When power is cut, the HLVD module triggers this
                    interrupt handler. The code immediately saves
                    state to non-volatile FLASH memory, allowing
                    data to be saved before Vdd drops below 
                    operating voltage.
 ********************************************************************/
void high_isr(void)
{
    HLVDCONbits.HLVDEN = 0;             // disable HLVD module to save power during critical save
    WriteFlash(flashAddress, counter);
    HLVDCONbits.HLVDEN = 1;             // re-enable HLVD module now that critical save is done
    
    printf("\r\nSaved %02X%02X to address %02X%02X.\r\n", 
        counter>>8, counter & 0x0FF, flashAddress >> 8, flashAddress & 0xFF);
    flashAddress += 2;

    PIE2bits.LVDIE = 0;                 // disable further HLVD interrupts until Vdd is stable again
}

void main(void)
{
    OSCCON = 0b01110011;                // switch to 8MHz INTOSC clock source
    Open1USART(USART_TX_INT_OFF & USART_RX_INT_OFF & USART_EIGHT_BIT & USART_ASYNCH_MODE & USART_ADDEN_OFF, BAUDRG);
    baud1USART(BAUD_IDLE_TX_PIN_STATE_HIGH & BAUD_IDLE_RX_PIN_STATE_HIGH & BAUD_AUTO_OFF & BAUD_WAKEUP_OFF & BAUD_16_BIT_RATE & USART_RX_INT_ON);

    RestoreSavedData();                 // restore saved counter value (if available) from FLASH memory 

    HLVDCONbits.HLVDL = 0b1100;         // set voltage trip point to 3.0V typical
    HLVDCONbits.VDIRMAG = 0;            // 0 = set flag when voltage falls below trip point
    HLVDCONbits.HLVDEN = 1;             // enable HLVD module
    while(HLVDCONbits.BGVST == 0);      // wait for stable bandgap reference voltage
    while(HLVDCONbits.IRVST == 0);      // wait for stable HLVD internal reference voltage
    WaitForStableVdd();                 // wait for stable Vdd

	INTCONbits.PEIE = 1;                // peripheral interrupt enable
	INTCONbits.GIE = 1;                 // global interrupt enable

    for(;;)
    {
        printf("\rCounter: %02X%02X", (counter >> 8), (counter & 0xFF));
        WaitForStableVdd();             // while Vdd is unstable, don't attempt recycling flash or other operations
        counter++;

        // If the non-volatile storage area is full, we need to
        // erase the page so that it can be re-used.
        if(flashAddress >= FLASH_STORAGE_END)
        {
            RecycleFlash();
        }
        PIE2bits.LVDIE = 1;             // FLASH space is available, allow HLVD interrupts
        
        wait();
        wait();
    }
}

 /*********************************************************************
 Function:        	void WaitForStableVdd(void)
 PreCondition:    	HLVD trip point must be configured and enabled
 Input:           	None
 Output:          	None
 Side Effects:    	None
 Overview:        	If the HLVD flag is getting set due to Vdd being
                    below the trip point, this routine will wait.
                    Once Vdd rises above the trip point and stays
                    above for several iterations, the routine will
                    return.
 ********************************************************************/
void WaitForStableVdd(void)
{
    unsigned int stable = 0xFFFF;
    while(stable--)
    {
        if(PIR2bits.LVDIF)
        {
            PIR2bits.LVDIF = 0;         // clear HLVD interrupt flag
            stable = 0xFFFF;
            printf("\r\nUnstable Vdd");
            wait();
        }
    }
}

void wait(void)
{
    int i;
    for(i = 0; i < 32000; i++)
    {
        Nop();
        Nop();
        Nop();
        Nop();
    }
}

 /*********************************************************************
 Function:        	void RestoreSavedData(void)
 PreCondition:    	None
 Input:           	None
 Output:          	counter global variable will be restored to the 
                    last value saved in FLASH memory. 
 Side Effects:    	None
 Overview:        	Restores the counter variable using FLASH memory 
                    F000h through F400h.
 ********************************************************************/
void RestoreSavedData(void)
{
    unsigned int temp;

    for(flashAddress = FLASH_STORAGE_START; flashAddress < FLASH_STORAGE_END; flashAddress += 2)
    {
        ReadFlash(flashAddress, 2, (unsigned char*)&temp);
        if(temp == 0xFFFF)
        {
            printf("\r\n");
            return;
        }
        printf("\r\nFound saved data: %02X%02X", temp >> 8, temp & 0xFF);
        counter = temp;
    }
}

 /*********************************************************************
 Function:        	void RecycleFlash(void)
 PreCondition:    	None
 Input:           	None
 Output:          	None
 Side Effects:    	flashAddress will be reset to FLASH_STORAGE_START+2
 Overview:        	Erases FLASH memory from FLASH_STORAGE_START to
                    FLASH_STORAGE_END. Writes back the current counter
                    value to FLASH before returning.
 ********************************************************************/
void RecycleFlash(void)
{
    // erase the page so that we have room again
    EraseFlash(FLASH_STORAGE_START, FLASH_STORAGE_END-1);

    // write back the current counter value
    WriteFlash(FLASH_STORAGE_START, counter);   
    flashAddress = FLASH_STORAGE_START + 2;

    printf("\r\nFLASH was full, erased page to make room again.\r\n");
}

 /*********************************************************************
 Function:        	void WriteFlash(unsigned long startaddr, unsigned int data)
 PreCondition:    	Necessary to erase flash block (1024 bytes) in 
                    application before writing if application had 
                    previously written data to this address.
 Input:           	startaddr - Address where FLASH will be written. 
                        Address must be even, else boundary mismatch 
                        will occur.
                    data - Word of data to be written into FLASH.
 Output:          	None
 Side Effects:    	None
 Overview:        	The function writes a word to FLASH memory. 
 ********************************************************************/
void WriteFlash(unsigned long startaddr, unsigned int data)
{
    unsigned char flag = 0;

    // Load the start address to FLASH address pointer registers
    TBLPTRU = (unsigned char)(startaddr >> 16);
    TBLPTRH = (unsigned char)(startaddr >> 8);	
    TBLPTRL	= (unsigned char)startaddr;
    
    TABLAT = (unsigned char)(data >> 8);
    _asm  
        TBLWTPOSTINC 	
    _endasm
    TABLAT =(unsigned char)data;
    _asm  
        TBLWTPOSTDEC
    _endasm
    
    // Flash write sequence
    EECON1bits.WPROG = 1;	
    EECON1bits.WREN = 1;
    if(INTCONbits.GIE)
    {
        flag = 1;
        INTCONbits.GIE = 0;
    }
    EECON2  = 0x55;
    EECON2  = 0xAA;
    EECON1bits.WR = 1;
    if(flag)
    {
        INTCONbits.GIE = 1;
    }		
}
