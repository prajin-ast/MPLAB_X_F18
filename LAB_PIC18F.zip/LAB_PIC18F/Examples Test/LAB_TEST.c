//-----------------------------------------------:
// File     : LAB_TEST.c
// Purpose  : TEST...
// Author   : Prajin Palangsantikul
// Compiler : MPLAB C18 Compiler
// Target   : PIC18Fxxxx
//-----------------------------------------------:

#include <p18cxxx.h>  // Device config form Project
#include <delays.h>   // PIC18 cycle-count delay routines.
#include <portb.h>    // PORTB routines.

//-----------------------------------------------:Configuration Bits
// HS Oscillator Selection, Watchdog Timer OFF
#pragma config OSC = HS,  WDT = OFF
// Low Voltage Programming : Disabled
#pragma config LVP = OFF

//-----------------------------------------------:Prototype
void high_isr (void);
void low_isr (void);

//-----------------------------------------------:delay for 1 ms
void delay_ms(unsigned int ms)
{ 
  for (;ms>0;ms--) 
  {
    Delay1KTCYx(5);  // Delay of 1 ms
  }
}

//-----------------------------------------------:NOTE
// RB0/INT0: External Interrupt pin
/*
//-----------------------------------------------:High Interrupt Vector
#pragma code high_vector = 0x08
void high_interrupt (void)
{
  _asm
    goto high_isr   //jump to interrupt routine
  _endasm
}
//-----------------------------------------------:High ISR
#pragma code 
#pragma interrupt high_isr
void high_isr (void)
{
  if (INTCONbits.INT0IF)    // Check for INT0 Interrupt
  {    
    INTCONbits.INT0IF = 0;  // Clear interrupt flag
    LATAbits.LATA0 = 1;     // High RA0
    delay_ms(100);          
    LATAbits.LATA0 = 0;     // Low RA0
  }
}
*/
//-----------------------------------------------:Low Interrupt Vector
#pragma code low_vector = 0x18
void low_interrupt (void)
{
  _asm
    goto low_isr   //jump to interrupt routine
  _endasm
}
//-----------------------------------------------:Low ISR
#pragma code 
#pragma interruptlow low_isr
void low_isr (void)
{
//  if (INTCON3bits.INT1IF)    // Check for INT0 Interrupt
  {    
    INTCON3bits.INT1IF = 0;  // Clear interrupt flag
    LATAbits.LATA2 = 1;     // High RA0
    delay_ms(100);          
    LATAbits.LATA2 = 0;     // Low RA0
  }
}

//-----------------------------------------------:Main
void main (void)
{
  ADCON1 = 0x0F;        // Set ALL PORT to Digital I/O

  // Configure INT0
  OpenRB1INT( PORTB_CHANGE_INT_ON &   // Interrupt enable
              FALLING_EDGE_INT &      // Interrupt on falling edge
              PORTB_PULLUPS_ON);      // pull-up resistors enabled

  INTCONbits.GIEH = 1;         // Enable global interrupts
  INTCONbits.GIEL = 1;
  RCONbits.IPEN = 1;			  // Enable priority levels

  TRISAbits.TRISA0 = 0; // Set RA0/RA1 output
  TRISAbits.TRISA1 = 0; 
  TRISAbits.TRISA2 = 0; 

  while (1)
  {             
    LATAbits.LATA1 = 1;   // Set LATA1
    delay_ms(500);    // Delay 0.5s
    LATAbits.LATA1 = 0;   // Set LATA1
    delay_ms(500);    // Delay 0.5s
  }
}
