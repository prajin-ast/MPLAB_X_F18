//-----------------------------------------------:
// File     : LAB_0603.c
// Purpose  : TIMER0 (Counter mode)
// Author   : Prajin Palangsantikul
// Compiler : MPLAB C18 Compiler
// Target   : PIC18Fxxxx
//-----------------------------------------------:
#include <p18cxxx.h>  // Device config form Project
#include <delays.h>   // PIC18 cycle-count delay routines.
#include <timers.h>    // Timer Functions

//-----------------------------------------------:Configuration Bits
// HS Oscillator Selection, Watchdog Timer OFF
#pragma config OSC = HS,  WDT = OFF
// Low Voltage Programming : Disabled
#pragma config LVP = OFF

//-----------------------------------------------:Prototype
void InterruptHandlerHigh (void);
void delay_ms(unsigned int ms);

//-----------------------------------------------:Interrupt vector
// High priority interrupt vector
#pragma code InterruptVectorHigh = 0x08
void InterruptVectorHigh (void)
{
  _asm
    goto InterruptHandlerHigh //jump to interrupt routine
  _endasm
}

// return to the default code section
#pragma code

//-----------------------------------------------:Interrupt routine
// High priority interrupt routine
#pragma interrupt InterruptHandlerHigh
void InterruptHandlerHigh (void)
{
  if (INTCONbits.TMR0IF)  // Check TMR0 interrupt flag 
  {
    LATAbits.LATA1 = 1;   // RA1 High
    delay_ms(500);        // Delay 0.5s
    LATAbits.LATA1 = 0;   // RA1 Low
    WriteTimer0(246);     // count start
    INTCONbits.TMR0IF = 0;  // Clear interrupt flag
  }
}

//-----------------------------------------------:delay for 1 ms
void delay_ms(unsigned int ms)
{ 
  for (;ms>0;ms--) 
  {
    Delay1KTCYx(5);  // Delay of 1 ms
  }
}

//-----------------------------------------------:Main
void main (void)
{
  PORTA = 0;  // Clear PORTA register 
  LATA = 0;   // Clear LATA register
    
  TRISAbits.TRISA0 = 0;   // Set RA0/1 output  
  TRISAbits.TRISA1 = 0;

  // Timer0 Configure
  OpenTimer0(TIMER_INT_ON &   // Interrupt enabled
             T0_8BIT &        // 8-bit mode
             T0_SOURCE_EXT &  // External clock source (I/O pin)
             T0_EDGE_RISE);   // External clock on rising edge
  
  INTCONbits.GIE = 1;     // Enable global interrupts  
  WriteTimer0(246);         // count start 

  while (1)
  {             
    LATAbits.LATA0 = 0;   // RA0 High
    delay_ms(300);        // Delay 0.3s
    LATAbits.LATA0 = 1;   // RA0 Low
    delay_ms(300);        // Delay 0.3s
  }
}
