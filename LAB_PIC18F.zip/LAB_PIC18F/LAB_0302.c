//-----------------------------------------------:
// File     : LAB_0302.c
// Purpose  : MPLAB IDE Sim
// Author   : Prajin Palangsantikul
// Compiler : MPLAB C18 Compiler
// Target   : PIC18Fxxxx
//-----------------------------------------------:
#include <p18cxxx.h>  // Device config form Project
#include <delays.h>   // PIC18 cycle-count delay routines

//-----------------------------------------------:Configuration Bits
// HS Oscillator Selection, Watchdog Timer OFF
#pragma config OSC = HS,  WDT = OFF
// Low Voltage Programming : Disabled
#pragma config LVP = OFF

//-----------------------------------------------:delay for 1 ms
void delay_ms(unsigned int ms)
{ 
  for (;ms>0;ms--) 
  {
    Delay1KTCYx(5);  // Delay of 1 ms
  }
}

//-----------------------------------------------:add_num
float add_num(float i, float j) 
{
  return(i + j);        // return function
}

//-----------------------------------------------:Main
void main(void) 
{
  float i, j;			      // Declarations
  float anum=0;			    // Definitions

  i = 5.4;
  j = 4.6;
  anum = add_num(i,j);	// call add_num()

  while(1);             // loop nothing
}

