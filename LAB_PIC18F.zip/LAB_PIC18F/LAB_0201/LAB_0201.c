#include <p18cxxx.h>        // Device config form Project

#pragma config WDT = OFF, OSC = HS  
#pragma config LVP = OFF

void delay (void)
{
	unsigned int i;
  
  for (i = 0; i < 50000 ; i++)
    ;
}

void main (void)
{
  PORTA = 0;  // Initialize PORTA by clearing output data latches 
  LATA = 0;   // Alternate method to clear output
  
  TRISA = 0;  // Set PORTA output
 
  while (1)
  {             
    LATAbits.LATA0 = 1;   // RA0 High
    delay();              // Loop delay
    LATAbits.LATA0 = 0;   // RA0 Low
    delay();              // Loop delay
  }
}
