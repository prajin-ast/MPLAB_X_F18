//-----------------------------------------------:
// File     : LAB_0701.c
// Purpose  : CCP1 (Capture Mode)
// Author   : Prajin Palangsantikul
// Compiler : MPLAB C18 Compiler
// Target   : PIC18Fxxxx
//-----------------------------------------------:
#include <p18cxxx.h>  // Device config form Project
#include <delays.h>   // PIC18 cycle-count delay routines.
#include <capture.h>  // Input Capture Function.

//-----------------------------------------------:Configuration Bits
// HS Oscillator Selection, Watchdog Timer OFF
#pragma config OSC = HS,  WDT = OFF
// Low Voltage Programming : Disabled
#pragma config LVP = OFF

//-----------------------------------------------:Prototype
void InterruptHandlerHigh (void);
void delay_ms(unsigned int ms);

//-----------------------------------------------:Interrupt vector
// High priority interrupt vector
#pragma code InterruptVectorHigh = 0x08
void InterruptVectorHigh (void)
{
  _asm
    goto InterruptHandlerHigh //jump to interrupt routine
  _endasm
}

// return to the default code section
#pragma code

//-----------------------------------------------:Interrupt routine
// High priority interrupt routine
#pragma interrupt InterruptHandlerHigh
void InterruptHandlerHigh (void)
{
  if (PIR1bits.CCP1IF)    // Check CCP1 Interrupt Flag
  { 
    LATAbits.LATA1 = 1;   // High RA1
    delay_ms(100);        // Delay 0.1s
    LATAbits.LATA1 = 0;   // Low RA1
    PIR1bits.CCP1IF = 0;  // Clear interrupt flag
  }
}

//-----------------------------------------------:delay for 1 ms
void delay_ms(unsigned int ms)
{ 
  for (;ms>0;ms--) 
  {
    Delay1KTCYx(5);  // Delay of 1 ms
  }
}

//-----------------------------------------------:Main
void main (void)
{
  PORTA = 0;  // Clear PORTA register 
  LATA = 0;   // Clear LATA register

  TRISAbits.TRISA0 = 0;   // Set RA0/1 output  
  TRISAbits.TRISA1 = 0;
  TRISCbits.TRISC2 = 1;   // Set RC2/CCP1 input

  // CCP1 Configure
  OpenCapture1(CAPTURE_INT_ON &       // Enable Capture Interrupt
               CAP_EVERY_FALL_EDGE);  // Every falling edge
               
  INTCONbits.PEIE = 1;    // Enable Peripheral Interrupt
  INTCONbits.GIE = 1;     // Enable global interrupts  
  
  while (1) 
  {
    // Toggle LED on RA0
    LATAbits.LATA0 = !LATAbits.LATA0; 
    delay_ms(500);        // Delay 0.5s
  }
}
