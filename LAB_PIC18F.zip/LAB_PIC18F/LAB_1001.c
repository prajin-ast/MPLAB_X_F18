//-----------------------------------------------:
// File     : LAB_1001.c
// Purpose  : MSSP (I2C Mode)
// Author   : Prajin Palangsantikul
// Compiler : MPLAB C18 Compiler
// Target   : PIC18Fxxxx
//-----------------------------------------------:
#include <p18cxxx.h>  // Device config form Project
#include <delays.h>   // PIC18 cycle-count delay routines
#include <usart.h>    // USART Functions
#include <stdlib.h>   // Use ultoa() Function
#include <i2c.h>      // I2C Functions

//-----------------------------------------------:Configuration Bits
// HS Oscillator Selection, Watchdog Timer OFF
#pragma config OSC = HS,  WDT = OFF
// Low Voltage Programming : Disabled
#pragma config LVP = OFF

#define EEPROM_ADR    0xA0      // 24LCxxx EEPROM ADDRESS

//-----------------------------------------------:delay for 1 ms
void delay_ms(unsigned int ms)
{ 
  for (;ms>0;ms--) 
  {
    Delay1KTCYx(5);  // Delay of 1 ms
  }
}

//-----------------------------------------------:EEPROM Write
void EEPROM_Write(unsigned int addr, unsigned char data)
{
  StartI2C();           // I2C Start
  WriteI2C(EEPROM_ADR); // Wirte Control Write
  IdleI2C();
  WriteI2C(addr>>8);    // Write Address High Byte
  IdleI2C();
  WriteI2C(addr);       // Write Address Low Byte
  IdleI2C();
  WriteI2C(data);       // Wrtie Data
  IdleI2C();
  StopI2C();            // I2C Stop
}

//-----------------------------------------------:EEPROM Read
unsigned char EEPROM_Read(unsigned int addr)
{
  unsigned char data;
  
  StartI2C();           // I2C Start
  WriteI2C(EEPROM_ADR); // Wirte Control Write
  IdleI2C();
  WriteI2C(addr>>8);    // Write Address High Byte
  IdleI2C();
  WriteI2C(addr);       // Write Address Low Byte
  IdleI2C();
  
  RestartI2C();           // ReStart I2C
  WriteI2C(EEPROM_ADR+1); // Wirte Control Read
  IdleI2C();
  data = ReadI2C();       // Read data
  IdleI2C();
  StopI2C();              // I2C Stop
  return (data);
}

//-----------------------------------------------:Main
void main (void)
{
  unsigned int addr = 0;
  unsigned char data;
  char str[10];
  
  PORTC = 0;      // Clear PORTC register 
  LATC = 0;       // Clear LATC register

  // USART Configure
  OpenUSART(USART_TX_INT_OFF &  // Transmit interrupt OFF
            USART_RX_INT_OFF &  // Receive interrupt OFF
            USART_ASYNCH_MODE & // Asynchronous Mode
            USART_EIGHT_BIT &   // 8-bit transmit/receive
            USART_CONT_RX &     // Continuous reception
            USART_BRGH_HIGH,    // High baud rate
            129);               // 8N1 9600 baud
  
  // I2C Configure
  OpenI2C(MASTER,     // I2C Master mode
          SLEW_ON);   // Slew rate enabled for 400kHz mode
          
  // I2C Master mode, clock = FOSC/(4 * (SSPADD + 1))          
  // SSPADD  = (20M/4x400k) - 1
  //         = 12.5 - 1        
  SSPADD = 11;    // 400kHz @20MHz
  
  // Write EEPROM
  putrsUSART("\f\n\rWrite EEPROM");
  for (addr=0; addr<10; addr++)  
  {
    data = 10+ addr;              // Data to write
    EEPROM_Write(addr, data);     // Write EEPROM
    putrsUSART("\n\rAdr: ");
    putsUSART(ultoa(addr, str));  // Print Address write
    putrsUSART(" Data: ");
    putsUSART(ultoa(data, str));  // Print Data write
  }
  // Read EEPROM
  putrsUSART("\n\rRead EEPROM");
  for (addr=0; addr<10; addr++)
  {
    putrsUSART("\n\rAdr: ");
    putsUSART(ultoa(addr, str));  // Print Address read
    putrsUSART(" Data: ");            
    data = EEPROM_Read(addr);     // Read EEPROM
    ultoa(data, str);
    putsUSART(str);               // Print data
  }

  while (1);      // Loop forever

}
