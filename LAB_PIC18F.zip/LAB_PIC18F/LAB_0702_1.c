//-----------------------------------------------:
// File     : LAB_0702_1.c
// Purpose  : CCP1 (Capture Mode)
// Author   : Prajin Palangsantikul
// Compiler : MPLAB C18 Compiler
// Target   : PIC18Fxxxx
//-----------------------------------------------:
#include <p18cxxx.h>  // Device config form Project
#include <delays.h>   // PIC18 cycle-count delay routines
#include <usart.h>    // USART Functions
#include <stdlib.h>   // Use ultoa() Function
#include <timers.h>   // Tiemrs Function
#include <capture.h>  // Input Capture Function

//-----------------------------------------------:Configuration Bits
// HS Oscillator Selection, Watchdog Timer OFF
#pragma config OSC = HS,  WDT = OFF
// Low Voltage Programming : Disabled
#pragma config LVP = OFF

#include "LIB_XLCD.C"       // LCD Module Library

//-----------------------------------------------:Prototype
void InterruptHandlerHigh (void);

//-----------------------------------------------:Interrupt vector
// High priority interrupt vector
#pragma code InterruptVectorHigh = 0x08
void InterruptVectorHigh (void)
{
  _asm
    goto InterruptHandlerHigh //jump to interrupt routine
  _endasm
}

// return to the default code section
#pragma code

//-----------------------------------------------:Interrupt routine
// High priority interrupt routine
#pragma interrupt InterruptHandlerHigh
void InterruptHandlerHigh (void)
{
  static int count_f = 0;
  static char count_t = 0;
  char str[30];

  if (PIR1bits.CCP1IF)    // CCP1 Interrupt Flag
  {    
    PIR1bits.CCP1IF = 0;  // Clear CCP1 interrupt flag     
    count_f++;            // Count Frequency
  }
  if (PIR1bits.TMR1IF)    // Timer1 Interrupt Flag
  { 
    PIR1bits.TMR1IF = 0;  // Clear Timer1 interrupt flag   
    if (count_t++ >= 76)  // Count Overflow  
    { 
      Write_strXLCD(1,2,"Freq:      Hz");    
      Write_intXLCD(7,2, count_f);
      count_t = 0;          // Clear count timer
      count_f = 0;          // Clear count frequency      
    }    
  }
}

//-----------------------------------------------:Main
void main (void)
{
  TRISCbits.TRISC2 = 1;     // Set RC2/CCP1 input

  // USART Configure
  OpenUSART(USART_TX_INT_OFF &  // Transmit interrupt OFF
            USART_RX_INT_OFF &  // Receive interrupt OFF
            USART_ASYNCH_MODE & // Asynchronous Mode
            USART_EIGHT_BIT &   // 8-bit transmit/receive
            USART_CONT_RX &     // Continuous reception
            USART_BRGH_HIGH,    // High baud rate
            129);               // 8N1 9600 baud

  // Timer1 Configure
  OpenTimer1(TIMER_INT_ON &    // Enable Timer1 Interrupts
             T1_16BIT_RW &     // Timer 1 is in 16 bit mode
             T1_SYNC_EXT_OFF & // Do not synchronize external clock input
             T1_SOURCE_INT &   // Internal clock source
             T1_PS_1_1);       // Prescaler 1:1

  WriteTimer1(0);             // Start count

  // CCP1 Configure
  OpenCapture1(CAPTURE_INT_ON &       // Enable Capture Interrupt
               CAP_EVERY_RISE_EDGE);  // Every rising edge

  INTCONbits.PEIE = 1;    // Enable Peripheral Interrupt
  INTCONbits.GIE = 1;     // Enable global interrupts

  Init_LCD();             // Initialize the LCD controller
  
  // Message to LCD
  Write_strXLCD(1,1,"Frequency Cap..");
  Write_strXLCD(1,2,"Freq:           ");

  while (1);              // Loop nothing
}
