//-----------------------------------------------:
// File     : LAB_0601_1.c
// Purpose  : TIMER0 (Timer mode)
// Author   : Prajin Palangsantikul
// Compiler : MPLAB C18 Compiler
// Target   : PIC18Fxxxx
//-----------------------------------------------:
#include <p18cxxx.h>  // Device config form Project
#include <delays.h>   // PIC18 cycle-count delay routines.

//-----------------------------------------------:Configuration Bits
// HS Oscillator Selection, Watchdog Timer OFF
#pragma config OSC = HS,  WDT = OFF
// Low Voltage Programming : Disabled
#pragma config LVP = OFF

unsigned int count = 0;

//-----------------------------------------------:Prototype
void InterruptHandlerHigh (void);
void delay_ms(unsigned int ms);

//-----------------------------------------------:Interrupt vector
// High priority interrupt vector
#pragma code InterruptVectorHigh = 0x08
void InterruptVectorHigh (void)
{
  _asm
    goto InterruptHandlerHigh //jump to interrupt routine
  _endasm
}

// return to the default code section
#pragma code

//-----------------------------------------------:Interrupt routine
// High priority interrupt routine
#pragma interrupt InterruptHandlerHigh
void InterruptHandlerHigh (void)
{
  if (INTCONbits.TMR0IF)  // Check TMR0 interrupt flag 
  {
    if (count++ >= 76)  
    {
      LATAbits.LATA0 = 1;   // RA0 High
      LATAbits.LATA1 = 1;   // RA1 High
      delay_ms(500);        // Delay 0.5s
      count = 0;            // Clear count
    }
    INTCONbits.TMR0IF = 0;  // Clear interrupt flag
  }
}

//-----------------------------------------------:delay for 1 ms
void delay_ms(unsigned int ms)
{ 
  for (;ms>0;ms--) 
  {
    Delay1KTCYx(5);  // Delay of 1 ms
  }
}

//-----------------------------------------------:Main
void main (void)
{
  PORTA = 0;  // Clear PORTA register 
  LATA = 0;   // Clear LATA register
    
  TRISAbits.TRISA0 = 0;   // Set RA0/1 output  
  TRISAbits.TRISA1 = 0;

  // Timer0 Configure
  T0CON = 0b11010111;     // Internal clock
                          // Prescaler is assigned
  INTCONbits.TMR0IE = 1;  // Enables Timer0 interrupt 
  INTCONbits.GIE = 1;     // Enable global interrupts  
  TMR0L = 0;              // Clear TMR0L

  while (1)
  {             
    LATAbits.LATA0 = 1;   // RA0 High
    LATAbits.LATA1 = 0;   // RA1 Low
    delay_ms(100);        // Delay 0.1s
    LATAbits.LATA0 = 0;   // RA0 Low
    LATAbits.LATA1 = 1;   // RA1 High
    delay_ms(100);        // Delay 0.1s
  }
}
