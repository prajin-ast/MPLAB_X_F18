//-----------------------------------------------:
// File     : LAB_0801.c
// Purpose  : ECCP (HALF-BRIDGE MODE)
// Author   : Prajin Palangsantikul
// Compiler : MPLAB C18 Compiler
// Target   : PIC18Fxxxx
//-----------------------------------------------:
#include <p18cxxx.h>  // Device config form Project
#include <timers.h>   // Tiemrs Function.
#include <pwm.h>      // Pulse-Width Modulation Functions

//-----------------------------------------------:Configuration Bits
// HS Oscillator Selection, Watchdog Timer OFF
#pragma config OSC = HS,  WDT = OFF
// Low Voltage Programming : Disabled
#pragma config LVP = OFF

//-----------------------------------------------:Main
void main (void)
{
  unsigned int dutycycle = 5;
  
  PORTC = 0;  // Clear PORTC register 
  LATC = 0;   // Clear LATC register
  PORTD = 0;  // Clear PORTC register 
  LATD = 0;   // Clear LATC register
  TRISC = 0;  // Set Output
  TRISD = 0;  // Set Output
  
  // Timer2 Configure
  OpenTimer2(TIMER_INT_OFF & // Disable Timer2 Interrupts
             T2_PS_1_1);     // Prescaler 1:1
             
  //Configuration ECCP module 
  OpenPWM1(63);           // PWM frequency 
  SetDCPWM1(dutycycle);   // Set Duty cycle
  // Set Mode
  SetOutputPWM1(HALF_OUT, PWM_MODE_1);        
  
  while (1)
  {
    dutycycle += 20;       // Up +20
    if (dutycycle>255)    // 8Bit Resolutions
      dutycycle = 5;
    SetDCPWM1(dutycycle); // change duty cycle
  }
}
