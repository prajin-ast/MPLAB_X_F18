//-----------------------------------------------:
// File     : APP_XLCD.c
// Purpose  : LCD 16x4
// Author   : Prajin Palangsantikul
// Compiler : MPLAB C18 Compiler
// Target   : PIC18Fxxxx
//-----------------------------------------------:
#include <p18cxxx.h>  // Device config form Project
#include <delays.h>   // PIC18 cycle-count delay routines

#include "LIB_LCD.c"   // LCD Library..

//-----------------------------------------------:Configuration Bits
// HS Oscillator Selection, Watchdog Timer OFF
#pragma config OSC = HS,  WDT = OFF
// Low Voltage Programming : Disabled
#pragma config LVP = OFF


//-----------------------------------------------:delay for 1 ms
void delay_ms(unsigned int ms)
{ 
  for (;ms>0;ms--) 
  {
    Delay1KTCYx(5);  // Delay of 1 ms
  }
}

//-----------------------------------------------:Main
void main(void) 
{
  // Init the LCD Display  
  OpenXLCD(FOUR_BIT & LINES_5X7);
  
  WaitLCD();    // Waiting LCD
  
  // Enable display with no cursor & unblinking
  WriteCmdXLCD(CURSOR_OFF & BLINK_OFF);  
  
  while(1)    // loop forever
  {
    LCD_gotoxy(1,1);    // column:1, row:1(line1)
    putrsXLCD("Hello World!");
    delay_ms(1000);
    LCD_gotoxy(1,1);
    putrsXLCD("            ");
    LCD_gotoxy(7,2);    // column:7, row:2(line2)
    putrsXLCD("Hello LCD!");
    delay_ms(1000);
    LCD_gotoxy(7,2);
    putrsXLCD("          ");
    LCD_gotoxy(1,3);    // column:1, row:3(line3)
    putrsXLCD("Hello World!");
    delay_ms(1000);
    LCD_gotoxy(1,3);
    putrsXLCD("            ");
    LCD_gotoxy(7,4);    // column:7, row:4(line4)
    putrsXLCD("Hello LCD!");
    delay_ms(1000);
    LCD_gotoxy(7,4);
    putrsXLCD("          ");    
  }
}

