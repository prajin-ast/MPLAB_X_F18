//-----------------------------------------------:
// File     : LAB_1601.c
// Purpose  : High/Low-Voltage Detect
// Author   : Prajin Palangsantikul
// Compiler : MPLAB C18 Compiler
// Target   : PIC18Fxxxx
// Ref.     : Example of Microchip Technology, Inc.
//-----------------------------------------------:
#include <p18cxxx.h>  // Device config form Project
#include <delays.h>   // PIC18 cycle-count delay routines
#include <usart.h>    // USART Functions

//-----------------------------------------------:Configuration Bits
// HS Oscillator Selection, Watchdog Timer OFF
#pragma config OSC = HS,  WDT = OFF
// Low Voltage Programming : Disabled
#pragma config LVP = OFF

//-----------------------------------------------:Prototype
void InterruptHandlerHigh (void);
void delay_ms(unsigned int ms);

//-----------------------------------------------:Interrupt vector
// High priority interrupt vector
#pragma code InterruptVectorHigh = 0x08
void InterruptVectorHigh (void)
{
  _asm
    goto InterruptHandlerHigh //jump to interrupt routine
  _endasm
}

// return to the default code section
#pragma code

//-----------------------------------------------:Interrupt routine
// High priority interrupt routine
#pragma interrupt InterruptHandlerHigh
void InterruptHandlerHigh (void)
{   
  if (PIR2bits.LVDIF)    // Check for HLVD Interrupt
  {    
    PIR2bits.LVDIF = 0;  // Clear interrupt flag
    putrsUSART("\fVoltage Detect Limit");
    LATAbits.LATA0 = 1;     // RA0 High
    delay_ms(100);
  }
}

//-----------------------------------------------:delay for 1 ms
void delay_ms(unsigned int ms)
{ 
  for (;ms>0;ms--) 
  {
    Delay1KTCYx(5);  // Delay of 1 ms
  }
}

//-----------------------------------------------:Wait for stable Vdd
void WaitForStableVdd(void)
{
  unsigned int stable = 0xFFFF;
  while(stable--)
  {
    if(PIR2bits.LVDIF)
    {
      PIR2bits.LVDIF = 0;         // clear HLVD interrupt flag
      stable = 0xFFFF;
      putrsUSART("\r\nUnstable Vdd");
      Delay1KTCYx(5);  // Delay of 1 ms
    }
  }
}

//-----------------------------------------------:Main
void main (void)
{  
  PORTA = 0;  // Clear PORTA register 
  LATA = 0;   // Clear LATA register
  
  TRISAbits.TRISA0 = 0;   // Set RA0 output

  // USART Configure
  OpenUSART(USART_TX_INT_OFF &  // Transmit interrupt OFF
            USART_RX_INT_OFF &  // Receive interrupt OFF
            USART_ASYNCH_MODE & // Asynchronous Mode
            USART_EIGHT_BIT &   // 8-bit transmit/receive
            USART_CONT_RX &     // Continuous reception
            USART_BRGH_HIGH,    // High baud rate
            129);               // 8N1 9600 baud

  // HLVD Configure
  HLVDCONbits.HLVDL0 = 1;       // External analog input is used (2.0V-5.5V)
  HLVDCONbits.HLVDL1 = 1;
  HLVDCONbits.HLVDL2 = 1;
  HLVDCONbits.HLVDL3 = 1;
  HLVDCONbits.VDIRMAG = 0;      // 0 = set flag when voltage falls below trip point
  HLVDCONbits.HLVDEN = 1;       // enable HLVD module
  while(HLVDCONbits.IRVST == 0);  // wait for stable HLVD internal reference voltage
  WaitForStableVdd();             // wait for stable Vdd

  // Interrupt Configure
  PIE2bits.HLVDIE = 1;    // Enable HLVD interrupts
  INTCONbits.GIE = 1;     // Enable global interrupts
  INTCONbits.PEIE = 1;    // Enable peripheral Interrupt 
    
  while (1)   // Loop forever
  {
    if (!PIR2bits.LVDIF)
    {
      putrsUSART("\fHigh/Low-Voltage Detect");
      putrsUSART("\n\rUse HLVDIN/RA5 input pin");
      LATAbits.LATA0 = 0;     // RA0 Low
      delay_ms(1000);  
    }
  }
}
