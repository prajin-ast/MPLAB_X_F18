//-----------------------------------------------:
// File     : LAB_1101.c
// Purpose  : EUSART (Polling mode)
// Author   : Prajin Palangsantikul
// Compiler : MPLAB C18 Compiler
// Target   : PIC18Fxxxx
//-----------------------------------------------:
#include <p18cxxx.h>  // Device config form Project
#include <delays.h>   // PIC18 cycle-count delay routines
#include <usart.h>    // USART Functions

//-----------------------------------------------:Configuration Bits
// HS Oscillator Selection, Watchdog Timer OFF
#pragma config OSC = HS,  WDT = OFF
// Low Voltage Programming : Disabled
#pragma config LVP = OFF

//-----------------------------------------------:Main
void main (void)
{
  char ch;
  
  // USART Configure
  OpenUSART(USART_TX_INT_OFF &  // Transmit interrupt OFF
            USART_RX_INT_OFF &  // Receive interrupt OFF
            USART_ASYNCH_MODE & // Asynchronous Mode
            USART_EIGHT_BIT &   // 8-bit transmit/receive
            USART_CONT_RX &     // Continuous reception
            USART_BRGH_HIGH,    // High baud rate
            129);               // 8N1 9600 baud
  
  putrsUSART("\f\n\rEUSART (Polling mode)\n\r");
  
  while (1)
  {
    while (DataRdyUSART()) {
      ch = ReadUSART();
      if (ch ==13) {
        putrsUSART("Key Enter\n\r");
      } else {
        putrsUSART("Key Press[ ");
        putcUSART(ch);
        putrsUSART(" ]\n\r");    
      }
    }
  }
}
