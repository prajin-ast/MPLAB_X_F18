//-----------------------------------------------:
// File     : LAB_0606.c
// Purpose  : TIMER3 (Timer mode)
// Author   : Prajin Palangsantikul
// Compiler : MPLAB C18 Compiler
// Target   : PIC18Fxxxx
//-----------------------------------------------:
#include <p18cxxx.h>  // Device config form Project
#include <delays.h>   // PIC18 cycle-count delay routines.
#include <timers.h>    // Timer Functions

//-----------------------------------------------:Configuration Bits
// HS Oscillator Selection, Watchdog Timer OFF
#pragma config OSC = HS,  WDT = OFF
// Low Voltage Programming : Disabled
#pragma config LVP = OFF

unsigned int count = 0;

//-----------------------------------------------:Prototype
void InterruptHandlerHigh (void);
void delay_ms(unsigned int ms);

//-----------------------------------------------:Interrupt vector
// High priority interrupt vector
#pragma code InterruptVectorHigh = 0x08
void InterruptVectorHigh (void)
{
  _asm
    goto InterruptHandlerHigh //jump to interrupt routine
  _endasm
}

// return to the default code section
#pragma code

//-----------------------------------------------:Interrupt routine
// High priority interrupt routine
#pragma interrupt InterruptHandlerHigh
void InterruptHandlerHigh (void)
{
  if (PIR2bits.TMR3IF)  // Check TMR3 interrupt flag 
  {
    if (count++ >= 10)  
    {
      LATAbits.LATA0 = 1;   // RA0 High
      LATAbits.LATA1 = 1;   // RA1 High
      delay_ms(500);        // Delay 0.5s
      count = 0;            // Clear count
    }
    PIR2bits.TMR3IF = 0;  // Clear interrupt flag
  }
}

//-----------------------------------------------:delay for 1 ms
void delay_ms(unsigned int ms)
{ 
  for (;ms>0;ms--) 
  {
    Delay1KTCYx(5);  // Delay of 1 ms
  }
}

//-----------------------------------------------:Main
void main (void)
{
  PORTA = 0;  // Clear PORTA register 
  LATA = 0;   // Clear LATA register
    
  TRISAbits.TRISA0 = 0;   // Set RA0/1 output  
  TRISAbits.TRISA1 = 0;

  // Timer3 Configure
  OpenTimer3(TIMER_INT_ON &   // Interrupt enabled
             T3_16BIT_RW &    // 16-bit mode
             T3_SOURCE_INT &  // Internal clock source (Tosc)
             T3_PS_1_8);      // 1:8 prescale
             
  INTCONbits.GIE = 1;     // Enable global interrupts
  INTCONbits.PEIE = 1;    // Enable peripheral Interrupt 
  WriteTimer3(0);         // Clear TMR3H/TMR3L

  while (1)
  {             
    LATAbits.LATA0 = 1;   // RA0 High
    LATAbits.LATA1 = 0;   // RA1 Low
    delay_ms(100);        // Delay 0.1s
    LATAbits.LATA0 = 0;   // RA0 Low
    LATAbits.LATA1 = 1;   // RA1 High
    delay_ms(100);        // Delay 0.1s
  }
}
