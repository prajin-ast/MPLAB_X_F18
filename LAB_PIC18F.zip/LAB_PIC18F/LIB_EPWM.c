#include <pwm.h>      // Pulse-Width Modulation Functions

//-----------------------------------------------:OpenEPWM1
void OpenEPWM1( char period )
{
  CCP1CON=0b00001100;   //ccpxm3:ccpxm0 11xx=pwm mode
  
  T2CONbits.TMR2ON = 0;  // STOP TIMER2 registers to POR state
  PR2 = period;          // Set period
  T2CONbits.TMR2ON = 1;  // Turn on PWM1
}

//-----------------------------------------------:CloseEPWM1
void CloseEPWM1(void)
{
 	CCP1CON = 0x0;           // Turn off PWM
}

//-----------------------------------------------:SetDCEPWM1
void SetDCEPWM1(unsigned int dutycycle)
{
  union PWMDC DCycle;

  // Save the dutycycle value in the union
  DCycle.lpwm = dutycycle << 6;

  // Write the high byte into ECCPR1L
  CCPR1L = DCycle.bpwm[1];

  // Write the low byte into ECCP1CON5:4
  CCP1CON = (CCP1CON & 0xCF) | ((DCycle.bpwm[0] >> 2) & 0x30);
}

//-----------------------------------------------:SetOutputEPWM1
void SetOutputEPWM1(unsigned char outputconfig, unsigned char outputmode)
{
  // #define __CONFIG3H 0x300005
  // #define __ECCPMX 1  /* bit 1 of __CONFIG3H */
  // static char eccpmx; /* will be set iff bit 1 of __CONFIG3H is set */

 // set P1M1 and P1M0
  CCP1CON = (CCP1CON | 0b11000000) & outputconfig;
  // set CCP1M3, CCP1M2, CCP1M1, CCP1M0
  CCP1CON = (CCP1CON | 0b00001111) & outputmode;

  if (SINGLE_OUT == outputconfig)
  {
      TRISDbits.TRISD4 = 0;
  }
  else if (IS_DUAL_PWM(outputconfig))
  {
      TRISDbits.TRISD4 = 0;
      TRISDbits.TRISD5 = 0;
  }
  else if (IS_QUAD_PWM(outputconfig))
  {
      TRISDbits.TRISD4 = 0;
      TRISDbits.TRISD5 = 0;
      TRISDbits.TRISD6 = 0;
      TRISDbits.TRISD7 = 0;
  }
}
