//-----------------------------------------------:
// File     : LAB_1502_2.c
// Purpose  : FLASH Program Memory
// Author   : Prajin Palangsantikul
// Compiler : MPLAB C18 Compiler
// Target   : PIC18Fxxxx
//-----------------------------------------------:
#include <p18cxxx.h>  // Device config form Project
#include <delays.h>   // PIC18 cycle-count delay routines
#include <usart.h>    // USART Functions
#include <stdlib.h>   // Use ultoa() Function
#include <flash.h>    // FLASH Functions

//-----------------------------------------------:Configuration Bits
// HS Oscillator Selection, Watchdog Timer OFF
#pragma config OSC = HS,  WDT = OFF
// Low Voltage Programming : Disabled
#pragma config LVP = OFF

//-----------------------------------------------:delay for 1 ms
void delay_ms(unsigned int ms)
{ 
  for (;ms>0;ms--) 
  {
    Delay1KTCYx(5);  // Delay of 1 ms
  }
}

//-----------------------------------------------:Main
void main (void)
{  
  unsigned char flash_w[10] = {1,2,3,4,5,6,7,8,9,10};
  unsigned char flash_r;
  char str[20];
  char i;

  // USART Configure
  OpenUSART(USART_TX_INT_OFF &  // Transmit interrupt OFF
            USART_RX_INT_OFF &  // Receive interrupt OFF
            USART_ASYNCH_MODE & // Asynchronous Mode
            USART_EIGHT_BIT &   // 8-bit transmit/receive
            USART_CONT_RX &     // Continuous reception
            USART_BRGH_HIGH,    // High baud rate
            129);               // 8N1 9600 baud
           
  EECON1bits.EEPGD = 1;   // Access Flash program memory
  EECON1bits.CFGS = 0;    // Access Flash program or data EEPROM memory

  putrsUSART("\f\n\rErase FLASH Memory");
  EraseFlash (0x7F40, 0x7F80);    // Erase 64 bytes
  putrsUSART("\n\rWrite FLASH Memory");
  WriteBlockFlash(0x7F40, 1, &flash_w[0]);

  putrsUSART("\n\rRead FLASH Memory");  
  for(i=0; i<10; i++)
  {
    LoadFlashAddr(0x7F40+i);
    TableRead(flash_r);
    putrsUSART("\n\r");
    putsUSART(ultoa(flash_r, str));
  }
    
  while (1);      // Loop forever
}
