//-----------------------------------------------:
// File     : LAB_1401.c
// Purpose  : Comparator
// Author   : Prajin Palangsantikul
// Compiler : MPLAB C18 Compiler
// Target   : PIC18Fxxxx
//-----------------------------------------------:
#include <p18cxxx.h>  // Device config form Project
#include <delays.h>   // PIC18 cycle-count delay routines
#include <usart.h>    // USART Functions
#include <stdlib.h>   // Use ultoa() Function
#include <ancomp.h>   // Analog Comparator Functions

//-----------------------------------------------:Configuration Bits
// HS Oscillator Selection, Watchdog Timer OFF
#pragma config OSC = HS,  WDT = OFF
// Low Voltage Programming : Disabled
#pragma config LVP = OFF

//-----------------------------------------------:delay for 1 ms
void delay_ms(unsigned int ms)
{ 
  for (;ms>0;ms--) 
  {
    Delay1KTCYx(5);  // Delay of 1 ms
  }
}

//-----------------------------------------------:Main
void main (void)
{  
  char str[20];

  // USART Configure
  OpenUSART(USART_TX_INT_OFF &  // Transmit interrupt OFF
            USART_RX_INT_OFF &  // Receive interrupt OFF
            USART_ASYNCH_MODE & // Asynchronous Mode
            USART_EIGHT_BIT &   // 8-bit transmit/receive
            USART_CONT_RX &     // Continuous reception
            USART_BRGH_HIGH,    // High baud rate
            129);               // 8N1 9600 baud
  
  // Comparator Configure
  // C1OUT: RA0(Vin-)<->RA3(Vin+), Output RA4
  // C2OUT: RA1(Vin-)<->RA2(Vin+), Output RA5
  Open_ancomp(COMP_OP_INV_NONE &  // Comparator 1,2  without OP invert 
              COMP_1_2_INDP_OP &  // Two independent comparator with Outputs
              COMP_INT_DIS);      // Comparator interrupt disable

  while (1)
  {
    putrsUSART("\f\n\rAnalog Comparator");
    putrsUSART("\n\rC1OUT : ");
    putsUSART(ultoa(CMCONbits.C1OUT, str));
    if (CMCONbits.C1OUT == 1) 
    {
      putrsUSART("\n\rRA3(Vin+) > RA0(Vin-)");
    } else {
      putrsUSART("\n\rRA3(Vin+) < RA0(Vin-)");
    }
    
    putrsUSART("\n\rC2OUT : ");
    putsUSART(ultoa(CMCONbits.C2OUT, str));
    if (CMCONbits.C2OUT == 1) 
    {
      putrsUSART("\n\rRA2(Vin+) > RA1(Vin-)");
    } else {
      putrsUSART("\n\rRA2(Vin+) < RA1(Vin-)");
    }
        
    delay_ms(500);
  }
}
