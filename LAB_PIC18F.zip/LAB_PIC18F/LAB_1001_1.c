//-----------------------------------------------:
// File     : LAB_1001_1.c
// Purpose  : MSSP (I2C Mode)
// Author   : Prajin Palangsantikul
// Compiler : MPLAB C18 Compiler
// Target   : PIC18Fxxxx
//-----------------------------------------------:
#include <p18cxxx.h>  // Device config form Project
#include <delays.h>   // PIC18 cycle-count delay routines
#include <usart.h>    // USART Functions
#include <stdlib.h>   // Use ultoa() Function
#include <i2c.h>      // I2C Functions

//-----------------------------------------------:Configuration Bits
// HS Oscillator Selection, Watchdog Timer OFF
#pragma config OSC = HS,  WDT = OFF
// Low Voltage Programming : Disabled
#pragma config LVP = OFF

#define EEPROM_ADR    0xA0      // EEPROM ADDRESS

//-----------------------------------------------:delay for 1 ms
void delay_ms(unsigned int ms)
{ 
  for (;ms>0;ms--) 
  {
    Delay1KTCYx(5);  // Delay of 1 ms
  }
}

//-----------------------------------------------:EEPROM Write
void EEPROM_Write(unsigned int addr, unsigned char data)
{
  StartI2C();
  //while(SSPCON2bits.SEN);
  
  WriteI2C(EEPROM_ADR);
  IdleI2C();
  WriteI2C(addr>>8);
  IdleI2C();
  WriteI2C(addr);
  IdleI2C();
  WriteI2C(data);
  IdleI2C();
  
  StopI2C();
  //while(SSPCON2bits.SEN);
}

//-----------------------------------------------:EEPROM Read
unsigned char EEPROM_Read(unsigned int addr)
{
  unsigned char data;
  
  StartI2C();
  //while(SSPCON2bits.SEN);
  
  WriteI2C(EEPROM_ADR);
  IdleI2C();
  WriteI2C(addr>>8);
  IdleI2C();
  WriteI2C(addr);
  IdleI2C();
  
  RestartI2C();
  //while(SSPCON2bits.SEN);
  
  WriteI2C(EEPROM_ADR+1);
  IdleI2C();
  data = ReadI2C();
  IdleI2C();

  StopI2C(); 
  //while(SSPCON2bits.SEN); 
  return (data);
}

//-----------------------------------------------:Main
void main (void)
{
  unsigned int addr = 0;
  unsigned char data;
  char str[10];
  
  PORTC = 0;      // Clear PORTC register 
  LATC = 0;       // Clear LATC register

  // USART Configure
  OpenUSART(USART_TX_INT_OFF &  // Transmit interrupt OFF
            USART_RX_INT_OFF &  // Receive interrupt OFF
            USART_ASYNCH_MODE & // Asynchronous Mode
            USART_EIGHT_BIT &   // 8-bit transmit/receive
            USART_CONT_RX &     // Continuous reception
            USART_BRGH_HIGH,    // High baud rate
            129);               // 8N1 9600 baud
  
  // I2C Configure
  OpenI2C(MASTER,     // I2C Master mode
          SLEW_ON);   // Slew rate enabled for 400kHz mode
  SSPADD = 0x18;      //400kHz Baud clock(9) @16MHz
  
  // Write EEPROM
  putrsUSART("\f\n\rWrite EEPROM");
  for (addr=0; addr<10; addr++)  
  {
    data = addr+10;
    EEPROM_Write(addr, data);
    putrsUSART("\n\rAdr: ");
    putsUSART(ultoa(addr, str));
    putrsUSART(" Data: ");
    putsUSART(ultoa(data, str));
  }
  // Read EEPROM
  putrsUSART("\n\rRead EEPROM");
  for (addr=0; addr<10; addr++)
  {
    putrsUSART("\n\rAdr: ");
    putsUSART(ultoa(addr, str));
    putrsUSART(" Data: ");            
    data = EEPROM_Read(addr);
    ultoa(data, str);
    putsUSART(str);
  }

  while (1);      // Loop forever

}
