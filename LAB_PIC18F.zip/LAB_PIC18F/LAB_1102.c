//-----------------------------------------------:
// File     : LAB_1102.c
// Purpose  : EUSART (Interrupt mode)
// Author   : Prajin Palangsantikul
// Compiler : MPLAB C18 Compiler
// Target   : PIC18Fxxxx
//-----------------------------------------------:
#include <p18cxxx.h>  // Device config form Project
#include <delays.h>   // PIC18 cycle-count delay routines
#include <usart.h>    // USART Functions

//-----------------------------------------------:Configuration Bits
// HS Oscillator Selection, Watchdog Timer OFF
#pragma config OSC = HS,  WDT = OFF
// Low Voltage Programming : Disabled
#pragma config LVP = OFF

//-----------------------------------------------:Prototype
void InterruptHandlerHigh (void);
void delay_ms(unsigned int ms);

//-----------------------------------------------:Interrupt vector
// High priority interrupt vector
#pragma code InterruptVectorHigh = 0x08
void InterruptVectorHigh (void)
{
  _asm
    goto InterruptHandlerHigh //jump to interrupt routine
  _endasm
}

// return to the default code section
#pragma code

//-----------------------------------------------:Interrupt routine
// High priority interrupt routine
#pragma interrupt InterruptHandlerHigh
void InterruptHandlerHigh (void)
{
  char ch;
  
  if (PIR1bits.RCIF)    // Check EUSART Receive Interrupt Flag
  {    
    ch = ReadUSART();
    if (ch == 13) {
      putrsUSART("Key Enter\n\r");
    } else {
      putrsUSART("Key Press[ ");
      putcUSART(ch);
      putrsUSART(" ]\n\r");    
    }
    PIR1bits.RCIF = 0;  // Clear interrupt flag
  }
}

//-----------------------------------------------:delay for 1 ms
void delay_ms(unsigned int ms)
{ 
  for (;ms>0;ms--) 
  {
    Delay1KTCYx(5);  // Delay of 1 ms
  }
}

//-----------------------------------------------:Main
void main (void)
{  
  PORTA = 0;  // Clear PORTA register 
  LATA = 0;   // Clear LATA register

  TRISAbits.TRISA0 = 0;   // Set RA0 output  
  
  // USART Configure
  OpenUSART(USART_TX_INT_OFF &  // Transmit interrupt OFF            
            USART_RX_INT_ON &   // Receive interrupt ON
            USART_ASYNCH_MODE & // Asynchronous Mode
            USART_EIGHT_BIT &   // 8-bit transmit/receive
            USART_CONT_RX &     // Continuous reception
            USART_BRGH_HIGH,    // High baud rate
            129);               // 8N1 9600 baud

  INTCONbits.PEIE = 1;    // Enable Peripheral Interrupt
  INTCONbits.GIE = 1;     // Enable global interrupts  
  
  putrsUSART("\f\n\rEUSART (Interrupt mode)\n\r");
  
  while (1)
  {
    LATAbits.LATA0 = 1;   // High RA1
    delay_ms(100);        // Delay 0.1s
    LATAbits.LATA0 = 0;   // Low RA1
    delay_ms(100);        // Delay 0.1s
  }
}
