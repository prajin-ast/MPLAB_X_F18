//-----------------------------------------------:
// File     : LAB_0403.c
// Purpose  : I/O PORTA,PORTB (2 LEDs 2 Switch)
// Author   : Prajin Palangsantikul
// Compiler : MPLAB C18 Compiler
// Target   : PIC18Fxxxx
//-----------------------------------------------:

#include <p18cxxx.h>  // Device config form Project

//-----------------------------------------------:Configuration Bits
// HS Oscillator Selection, Watchdog Timer OFF
#pragma config OSC = HS,  WDT = OFF
// Low Voltage Programming : Disabled
#pragma config LVP = OFF

//-----------------------------------------------:Main
void main (void)
{
  PORTA = 0;  // Clear PORTA register 
  LATA = 0;   // Clear LATA register
  PORTB = 0;  // Clear PORTB register 
  LATB = 0;   // Clear LATB register
  
  TRISAbits.TRISA1 = 0; // Set RA1 output
  TRISBbits.TRISB1 = 0; // Set RB1 output
  
  ADCON1 = 0x0F;        // Configure A/D for digital inputs

  while (1)
  {             
    if (PORTAbits.RA0 == 0) // Read RA0
    {
	  	LATAbits.LATA1 = 1;   // RA1 High
    } else {
    	LATAbits.LATA1 = 0;		// RA1 Low
    }
    if (PORTBbits.RB0 == 0) // Read RB0
    {
    	LATBbits.LATB1 = 1;   // RB1 High
    } else {
    	LATBbits.LATB1 = 0;   // RB1 Low
    }
  }
}
