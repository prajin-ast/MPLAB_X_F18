//-----------------------------------------------:
// File     : LAB_1301.c
// Purpose  : Comparator Voltage Reference
// Author   : Prajin Palangsantikul
// Compiler : MPLAB C18 Compiler
// Target   : PIC18Fxxxx
//-----------------------------------------------:
#include <p18cxxx.h>  // Device config form Project
#include <delays.h>   // PIC18 cycle-count delay routines

//-----------------------------------------------:Configuration Bits
// HS Oscillator Selection, Watchdog Timer OFF
#pragma config OSC = HS,  WDT = OFF
// Low Voltage Programming : Disabled
#pragma config LVP = OFF

//-----------------------------------------------:delay for 1 ms
void delay_ms(unsigned int ms)
{ 
  for (;ms>0;ms--) 
  {
    Delay1KTCYx(5);  // Delay of 1 ms
  }
}

//-----------------------------------------------:Main
void main (void)
{  
  char CVR_CFG, CVR3_0;
  
  CVRCONbits.CVREN = 1;   // CVREF circuit powered on
  CVRCONbits.CVROE = 1;   // Output on the RA2/AN2/VREF-/CVREF pin
  CVRCONbits.CVRR = 0;    // 0.25 CVRSRC to 0.75 CVRSRC
  CVRCONbits.CVRSS = 0;   // Comparator reference source, CVRSRC = VDD � VSS

  CVR_CFG = CVRCON;       // Save Config CVRCON
  CVR3_0 = 0;             // Config CVR0-CVR3 = 0
  
  while (1)
  {
    CVRCON = (CVR_CFG | CVR3_0); // Config CVRCON
    CVR3_0++;         // CVR3_0 = CVR3_0 + 1
    if (CVR3_0 > 15)  // if TRUE CVR3_0 = 0
      CVR3_0 = 0;
    delay_ms(500);
  }
}
