//-----------------------------------------------:
// File     : LAB_0901_2.c
// Purpose  : MSSP (SPI Mode)
// Author   : Prajin Palangsantikul
// Compiler : MPLAB C18 Compiler
// Target   : PIC18Fxxxx
//-----------------------------------------------:
#include <p18cxxx.h>  // Device config form Project
#include <delays.h>   // PIC18 cycle-count delay routines
#include <spi.h>      // SPI Functions

//-----------------------------------------------:Configuration Bits
// HS Oscillator Selection, Watchdog Timer OFF
#pragma config OSC = HS,  WDT = OFF
// Low Voltage Programming : Disabled
#pragma config LVP = OFF

#define CFG_DACA   0x3000  //0b0011 000000000000 
#define CFG_DACB   0xB000  //0b1011 000000000000

#define SET_SCK           TRISCbits.TRISC3
#define SET_SDO           TRISCbits.TRISC5
#define SET_CS            TRISAbits.TRISA0
#define SET_LDAC          TRISAbits.TRISA1
#define DAC_CS            LATAbits.LATA0
#define DAC_LDAC          LATAbits.LATA1

//-----------------------------------------------:delay for 1 ms
void delay_ms(unsigned int ms)
{ 
  for (;ms>0;ms--) 
  {
    Delay1KTCYx(5);  // Delay of 1 ms
  }
}

//-----------------------------------------------:Write DAC
void write_dac(unsigned int data)
{
  DAC_LDAC = 1;
  DAC_CS = 0;
  Nop();
  while(WriteSPI(data>>8));
  while(WriteSPI(data));
  DAC_CS = 1;     
  Nop();
  DAC_LDAC = 0;   
  Nop(); Nop();
  DAC_LDAC = 1;
}

//-----------------------------------------------:Main
void main (void)
{
  unsigned int dac = 100;
  
  PORTA = 0;      // Clear PORTA register 
  LATA = 0;       // Clear LATA register
  PORTC = 0;      // Clear PORTC register 
  LATC = 0;       // Clear LATC register
  
  SET_SDO = 0;    // Set RC5/SDO, RC3/SCK  
  SET_SCK = 0;   
  SET_CS = 0;     // Set CS/LDAC output  
  SET_LDAC = 0;

  // SPI Configure
  OpenSPI(SPI_FOSC_16,  // SPI Master mode, clock = Fosc/64
          MODE_00,      // Setting for SPI bus Mode 0,0
          SMPEND);      // Input data sample at end of data out      
  
  write_dac(CFG_DACA|0);
  write_dac(CFG_DACB|0);

  while (1)
  {
    write_dac(CFG_DACA|dac);
    dac +=100;
    if (dac > 4095) dac = 0; 
    delay_ms(100);
  }
}
