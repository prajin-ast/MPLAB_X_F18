//-----------------------------------------------:
// File     : LAB_0301.c
// Purpose  : MPLAB IDE Sim
// Author   : Prajin Palangsantikul
// Compiler : MPLAB C18 Compiler
// Target   : PIC18Fxxxx
//-----------------------------------------------:
#include <p18cxxx.h>  // Device config form Project
#include <delays.h>   // PIC18 cycle-count delay routines

//-----------------------------------------------:Configuration Bits
// HS Oscillator Selection, Watchdog Timer OFF
#pragma config OSC = HS,  WDT = OFF, DEBUG = ON
// Low Voltage Programming : Disabled
#pragma config LVP = OFF

//-----------------------------------------------:delay for 1 ms
void delay_ms(unsigned int ms)
{ 
  for (;ms>0;ms--) 
  {
    Delay1KTCYx(5);  // Delay of 1 ms
  }
}

//-----------------------------------------------:Main
void main (void)
{
  PORTA = 0;  // Clear PORTA register 
  LATA = 0;   // Clear LATA register
  
  TRISAbits.TRISA0 = 0;   // Set RA0/RA1 output
  TRISAbits.TRISA1 = 0;
    
  ADCON1 = 0x0F;  // Off Analog input
  
  while (1)   // Loop forever
  {
    LATAbits.LATA0 = 0;   // RA0 Low
    LATAbits.LATA1 = 1;   // RA1 High
    delay_ms(1);
    LATAbits.LATA1 = 0;   // RA1 Low
    LATAbits.LATA0 = 1;   // RA0 High
    delay_ms(1);    
  }
}
