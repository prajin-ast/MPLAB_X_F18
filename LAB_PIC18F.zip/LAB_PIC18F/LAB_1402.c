//-----------------------------------------------:
// File     : LAB_1402.c
// Purpose  : Comparator
// Author   : Prajin Palangsantikul
// Compiler : MPLAB C18 Compiler
// Target   : PIC18Fxxxx
//-----------------------------------------------:
#include <p18cxxx.h>  // Device config form Project
#include <delays.h>   // PIC18 cycle-count delay routines
#include <usart.h>    // USART Functions
#include <stdlib.h>   // Use ultoa() Function
#include <ancomp.h>   // Analog Comparator Functions

//-----------------------------------------------:Configuration Bits
// HS Oscillator Selection, Watchdog Timer OFF
#pragma config OSC = HS,  WDT = OFF
// Low Voltage Programming : Disabled
#pragma config LVP = OFF

//-----------------------------------------------:Prototype
void InterruptHandlerHigh (void);
void delay_ms(unsigned int ms);

//-----------------------------------------------:Interrupt vector
// High priority interrupt vector
#pragma code InterruptVectorHigh = 0x08
void InterruptVectorHigh (void)
{
  _asm
    goto InterruptHandlerHigh //jump to interrupt routine
  _endasm
}

// return to the default code section
#pragma code

//-----------------------------------------------:Interrupt routine
// High priority interrupt routine
#pragma interrupt InterruptHandlerHigh
void InterruptHandlerHigh (void)
{  
  char str[10];

  if (PIR2bits.CMIF)    // Check Analog Comparator Interrupt Flag
  {    
    putrsUSART("\f\n\rAnalog Comparator");
    putrsUSART("\n\rInterrupt");
    putrsUSART("\n\rC1OUT: ");
    putsUSART(ultoa(CMCONbits.C1OUT, str));    
    putrsUSART("\n\rC2OUT: ");
    putsUSART(ultoa(CMCONbits.C2OUT, str));    

    PIR2bits.CMIF = 0;  // Clear interrupt flag
  }
}

//-----------------------------------------------:delay for 1 ms
void delay_ms(unsigned int ms)
{ 
  for (;ms>0;ms--) 
  {
    Delay1KTCYx(5);  // Delay of 1 ms
  }
}

//-----------------------------------------------:Main
void main (void)
{  
  // USART Configure
  OpenUSART(USART_TX_INT_OFF &  // Transmit interrupt OFF
            USART_RX_INT_OFF &  // Receive interrupt OFF
            USART_ASYNCH_MODE & // Asynchronous Mode
            USART_EIGHT_BIT &   // 8-bit transmit/receive
            USART_CONT_RX &     // Continuous reception
            USART_BRGH_HIGH,    // High baud rate
            129);               // 8N1 9600 baud
  
  // Comparator Configure
  // C1OUT: RA0(Vin-)<->RA3(Vin+), Output RA4
  // C2OUT: RA1(Vin-)<->RA2(Vin+), Output RA5
  Open_ancomp(COMP_OP_INV_NONE &  // Comparator 1,2  without OP invert 
              COMP_1_2_INDP_OP &  // Two independent comparator with Outputs
              COMP_INT_EN);       // Comparator interrupt enable

  INTCONbits.PEIE = 1;    // Enable Peripheral Interrupt
  INTCONbits.GIE = 1;     // Enable global interrupts 
  
  while (1);              // Loop forever

}
