//-----------------------------------------------:
// File     : APP_SW_UART.c
// Purpose  : Software UART
// Author   : Prajin Palangsantikul
// Compiler : MPLAB C18 Compiler
// Target   : PIC18Fxxxx
//-----------------------------------------------:
#include <p18cxxx.h>  // Device config form Project
#include <delays.h>   // PIC18 cycle-count delay routines

#include <sw_uart.h>  // Software UART

//-----------------------------------------------:Configuration Bits
// HS Oscillator Selection, Watchdog Timer OFF
#pragma config OSC = HS,  WDT = OFF
// Low Voltage Programming : Disabled
#pragma config LVP = OFF


//-----------------------------------------------:DelayTXBitUART
void DelayTXBitUART(void)
{
  //Delay: 509 cycles  
  Delay10TCYx(50);
  Delay1TCY();  Delay1TCY();  Delay1TCY();
  Delay1TCY();  Delay1TCY();  Delay1TCY();
  Delay1TCY();  Delay1TCY();  Delay1TCY();  
}
//-----------------------------------------------:DelayRXHalfBitUART
void DelayRXHalfBitUART(void)
{
  // Delay: 251 cycles
  Delay10TCYx(25);
  Delay1TCY();

}
//-----------------------------------------------:DelayRXBitUART
void DelayRXBitUART(void)
{  
  // Delay: 507 cycles
  Delay10TCYx(50);
  Delay1TCY();  Delay1TCY();  Delay1TCY();
  Delay1TCY();  Delay1TCY();  Delay1TCY();
  Delay1TCY(); 
}

//-----------------------------------------------:Main
void main(void) 
{
  char str1[] = "\fHello SW UART (key press)\n\r";
  char str2[] = "\n\rKey Press[ ";
  char str3[] = " ]";
  char data;
  
  // configure software UART
  OpenUART();
 
  putsUART(str1); // put string1
  
  while( 1 )
  {
    data = ReadUART();  // read a byte
    putsUART(str2);     // put string2
    WriteUART( data );  // bounce it back    
    putsUART(str3);     // put string3
  }
}

