//-----------------------------------------------:
// File     : Calc_SW_UARTc
// Purpose  : Software UART Delay Functions
// Author   : Prajin Palangsantikul
// Compiler : Borland C Compiler
// Target   : Computer
//-----------------------------------------------:

#include <stdio.h>
#include <conio.h>

void main(void)
{
	float a;
	unsigned long Fosc, baud;

	Fosc = 20000000;
   baud = 9600;

	a = ((((2*Fosc) / (4*baud)) + 1) / 2) - 12;
	printf("\n%f",a);
	a = ((((2*Fosc) / (8*baud)) + 1) / 2) - 9;
	printf("\n%f",a);
	a = ((((2*Fosc) / (4*baud)) + 1) / 2) - 14;
	printf("\n%f",a);

	getchar();
}