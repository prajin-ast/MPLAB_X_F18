//-----------------------------------------------:
// File     : LAB_0703.c
// Purpose  : CCP1 (Compare Mode)
// Author   : Prajin Palangsantikul
// Compiler : MPLAB C18 Compiler
// Target   : PIC18Fxxxx
//-----------------------------------------------:
#include <p18cxxx.h>  // Device config form Project
#include <delays.h>   // PIC18 cycle-count delay routines
#include <timers.h>   // Tiemrs Function
#include <compare.h>  // Output Compare Functions

//-----------------------------------------------:Configuration Bits
// HS Oscillator Selection, Watchdog Timer OFF
#pragma config OSC = HS,  WDT = OFF
// Low Voltage Programming : Disabled
#pragma config LVP = OFF

//-----------------------------------------------:Prototype
void InterruptHandlerHigh (void);
void delay_ms(unsigned int ms);

//-----------------------------------------------:Interrupt vector
// High priority interrupt vector
#pragma code InterruptVectorHigh = 0x08
void InterruptVectorHigh (void)
{
  _asm
    goto InterruptHandlerHigh //jump to interrupt routine
  _endasm
}

// return to the default code section
#pragma code

//-----------------------------------------------:Interrupt routine
// High priority interrupt routine
#pragma interrupt InterruptHandlerHigh
void InterruptHandlerHigh (void)
{
  static count_compare = 0;
  
  if (PIR1bits.CCP1IF)    // Check CCP1 Interrupt Flag
  {     
    if (count_compare++ == 2)
    {
      LATAbits.LATA0 = 1;   // High RA0
      delay_ms(100);        // Delay 0.1s
      LATAbits.LATA0 = 0;   // Row RA0
      count_compare = 0;    // Clear count
    }
    PIR1bits.CCP1IF = 0;  // Clear interrupt flag
  }
}

//-----------------------------------------------:delay for 1 ms
void delay_ms(unsigned int ms)
{ 
  for (;ms>0;ms--) 
  {
    Delay1KTCYx(5);  // Delay of 1 ms
  }
}

//-----------------------------------------------:Main
void main (void)
{
  PORTA = 0;  // Clear PORTA register 
  LATA = 0;   // Clear LATA register
  PORTC = 0;  // Clear PORTC register 
  LATC = 0;   // Clear LATc register

  TRISAbits.TRISA0 = 0;   // Set RA0 output  
  TRISCbits.TRISC2 = 0;   // Set RC2/CCP1 Output
  
  // Timer1 Configure
  OpenTimer1(TIMER_INT_ON &    // Enable Timer1 Interrupts
             T1_16BIT_RW &     // Timer 1 is in 16 bit mode
             T1_SYNC_EXT_OFF & // Do not synchronize external clock input
             T1_SOURCE_INT &   // Internal clock source
             T1_PS_1_8);       // Prescaler 1:8
             
  // CCP1 Configure
  OpenCompare1(COM_INT_ON &     // Enable Compare Interrupt
               COM_TOGG_MATCH,  // Toggle output on match
               65535);          // CCPR1H/L
  
  INTCONbits.PEIE = 1;    // Enable Peripheral Interrupt
  INTCONbits.GIE = 1;     // Enable global interrupts  
  
  while (1);              // Loop nothing
}
